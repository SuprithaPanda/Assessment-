function reverseWords(sentence) {
    return sentence.split(' ').map(word => word.split('').reverse().join('')).join(' ');
  }
  
  // Example usage:
  const inputSentence = "Take a sentence as an input and reverse every word";
  const reversedSentence = reverseWords(inputSentence);
  console.log(reversedSentence);
  