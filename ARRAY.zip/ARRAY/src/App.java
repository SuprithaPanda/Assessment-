import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class App {
    public static void main(String[] args) {
        
        Integer[] array = {1, 2, 3, 4, 5, 6, 7};

        
        ArrayList<Integer> arrayList = new ArrayList<>(Arrays.asList(array));

        
        Collections.shuffle(arrayList);

        
        Integer[] shuffledArray = arrayList.toArray(new Integer[0]);

        
        System.out.println("Shuffled array: " + Arrays.toString(shuffledArray));
    }
}
