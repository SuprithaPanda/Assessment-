// Array to be sorted
let arrayToSort = [4, 2, 7, 1, 3, 9, 5];

// Sorting the array in descending order
arrayToSort.sort((a, b) => b - a);

// Display the sorted array
console.log("Sorted array in descending order: " + arrayToSort);
